<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::get('/usuario', function () {
    return view('usuario/crear_usuario');
});

Route::get('/usuario_admin', function () {
    return view('usuario/admin/administrador');
});

Route::get('/hello', function () {
    return response('Proyecto de laravel');
});

Route::get('/hellos', function () {
    return response('Hola Todos ...!', 200)
    ->header('Content-Type', 'text/plain')
    ->header('foo', 'bar');
});

Route::get('/post/{id},{ID}', function ($id,$ID) {
    return response ('PARAMETRO 1: ' . $id .' - PARAMETRO 2: ' . $ID);
})  ->where('id', '[a-z, A-Z]+')
    ->where('ID', '[0-9]+');

Route::get('/posts/{id}', function ($id) {
    ddd($id); //para realizar debug
    return response ('Post: ' . $id);
})->where('id', '[a-z, A-Z, 0-9]+') ;

Route::get('/buscar', function (Request $request) {
    dd($request);
});
