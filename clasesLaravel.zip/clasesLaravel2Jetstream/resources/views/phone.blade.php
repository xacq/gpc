<x-app-layout>

    <h1>LISTA DE TELEFONO<</h1>


</x-app-layout>
