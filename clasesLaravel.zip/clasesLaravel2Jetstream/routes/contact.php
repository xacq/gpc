<?php

use Illuminate\Support\Facades\Route;


Route::get('/contact', function () {
    return view('contact');
})->middleware(['auth', 'verified'])->name('contact')

?>
