    <h1><?php echo $titulo?></h1>
    <?php
    foreach ($listados as $listado):?>
        <h2><?php echo $listado['titulo']; ?></h2>
        <p><?php echo $listado['descripcion']; ?></p>
    <?php endforeach; ?>
