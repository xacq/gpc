
@foreach ($info as $dato)
    <h2>{{ $dato['titulo'] }}</h2>
    <p>{{ $dato['descripcion'] }} </p>
@endforeach

