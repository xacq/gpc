<?php

use Illuminate\Support\Facades\Route;
use App\Models\listadosModelo;
use App\Http\Controllers\listadosControlador;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/listados', function () {
    return view('listados',[
        'titulo' => 'Ultimo Listado',
        'listados' => [
            [
                'id' => 1,
                'titulo' => 'Listado Uno',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '
            ],
            [
                'id' => 2,
                'titulo' => 'Listado Dos',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '
            ],
            [
                'id' => 3,
                'titulo' => 'Listado Tres',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '

            ]
        ]
    ]);
});

Route::get('/listadosRuta',[listadosControlador::class,'listadosTodo'])
        ->name('listadosVista');
