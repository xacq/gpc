<?php

namespace App\Http\Controllers;

use App\Models\listadosModelo;

class listadosControlador extends Controller
{
    public function listadosTodo(){
        $info = listadosModelo::todo_json();
        return view('listadosVista', compact('info'));
    }
}
