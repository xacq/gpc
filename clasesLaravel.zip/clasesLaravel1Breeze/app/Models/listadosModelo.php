<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class listadosModelo extends Model
{
    use HasFactory;
    public static function todo_json(){
        return [
            [
                'id' => 1,
                'titulo' => 'Listado Uno',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '
            ],
            [
                'id' => 2,
                'titulo' => 'Listado Dos',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '
            ],
            [
                'id' => 3,
                'titulo' => 'Listado Tres',
                'descripcion' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla dictum nulla quis gravida aliquet.
                                Cras in lacus quis nibh laoreet vestibulum. Donec ac nisl arcu. Aliquam erat volutpat. Nunc mattis
                                molestie sapien, vitae condimentum ex ullamcorper non. Fusce rhoncus ipsum id dolor volutpat placerat.
                                Cras quis diam vel turpis cursus bibendum. Nam sed consequat mi. Vivamus orci erat, egestas et malesuada
                                nec, ultricies at erat. '

            ]
        ];
    }
}
