
<?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($dato['titulo']); ?></h2>
    <p><?php echo e($dato['descripcion']); ?> </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\LARAVEL\clasesLaravel1\resources\views/listadosv2.blade.php ENDPATH**/ ?>