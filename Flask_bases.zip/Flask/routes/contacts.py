from flask import Blueprint, render_template

contacts = Blueprint('contacts', __name__)

@contacts.route("/")
def home():
    return render_template('home.html')

@contacts.route("/login")
def login():
    return render_template('login.html')

@contacts.route("/list_users")
def list_users():
    return render_template('lista_users.html')