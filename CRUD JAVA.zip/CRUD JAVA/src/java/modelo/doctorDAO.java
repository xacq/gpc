/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import config.conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class doctorDAO {
 
    Connection Conexion;
    
    public doctorDAO(){
    
        conexion con = new conexion();
        Conexion = con.getConexion();
    }
    
    public List<doctor> listarDoctores(){
    
        PreparedStatement ps;
        ResultSet rs;
        
        List<doctor> lista= new ArrayList<>();
        
        try{
            ps = Conexion.prepareStatement("SELECT * FROM cit_med_doctores ORDER BY cit_med_doctoresnombre");
            rs = ps.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("cit_med_doctoresid");
                String nombre = rs.getString("cit_med_doctoresnombre");
                String telefono = rs.getString("cit_med_doctorestelefono");
                String correo = rs.getString("cit_med_doctorescorreo");
                String direccion = rs.getString("cit_med_doctoresdireccion");
                String especializacion = rs.getString("cit_med_doctoresespecializacion");
                Double precio = rs.getDouble("cit_med_doctoresvalor");
                Date fecha = rs.getDate("cit_med_doctoresfechaingreso");
                
                doctor doc = new doctor(id,nombre, telefono, correo, direccion, especializacion, precio, fecha);
                lista.add(doc);
            }
               return lista;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
    }
    
    public doctor mostrarDoctores( int _id){
    
        PreparedStatement ps;
        ResultSet rs;
        
        doctor doc = null;
        
        try{
            ps = Conexion.prepareStatement("SELECT * FROM cit_med_doctores WHERE cit_med_doctoresid = ?");
            ps.setInt(1,_id);
            rs = ps.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("cit_med_doctoresid");
                String nombre = rs.getString("cit_med_doctoresnombre");
                String telefono = rs.getString("cit_med_doctorestelefono");
                String correo = rs.getString("cit_med_doctorescorreo");
                String direccion = rs.getString("cit_med_doctoresdireccion");
                String especializacion = rs.getString("cit_med_doctoresespecializacion");
                Double precio = rs.getDouble("cit_med_doctoresvalor");
                Date fecha = rs.getDate("cit_med_doctoresfechaingreso");
                
                doc = new doctor(id,nombre, telefono, correo, direccion, especializacion, precio, fecha);                               
            }
               return doc;
        }catch(SQLException e){
            System.out.println(e.toString());
            return null;
        }
    }
    
    public boolean insertarDoctores(doctor doc){
    
        PreparedStatement ps;
        
        try{
            ps = Conexion.prepareStatement("INSERT INTO cit_med_doctores (cit_med_doctoresid,cit_med_doctoresnombre,cit_med_doctorestelefono,"
                    + "cit_med_doctorescorreo,cit_med_doctoresdireccion,cit_med_doctoresespecializacion,cit_med_doctoresvalor,cit_med_doctoresfechaingreso)"
                    + "VALUES (?,?,?,?,?,?,?,current_timestamp())");
            
            ps.setInt(1,doc.getId());
            ps.setString(2,doc.getNombre());
            ps.setString(3,doc.getTelefono());
            ps.setString(4,doc.getCorreo());
            ps.setString(5,doc.getDireccion());
            ps.setString(6,doc.getEspecializacion());
            ps.setDouble(7,doc.getPrecio());        
            
            ps.execute();
   
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
    
    public boolean actualizarDoctores(doctor doc){
    
        PreparedStatement ps;
        
        try{
            ps = Conexion.prepareStatement("UPDATE cit_med_doctores SET cit_med_doctoresnombre = ?,cit_med_doctorestelefono = ?, cit_med_doctorescorreo = ?,cit_med_doctoresdireccion = ?, cit_med_doctoresespecializacion = ?,cit_med_doctoresvalor = ?,cit_med_doctoresfechaingreso = current_timestamp() WHERE cit_med_doctoresid = ?");
            
            ps.setString(1,doc.getNombre());
            ps.setString(2,doc.getTelefono());
            ps.setString(3,doc.getCorreo());
            ps.setString(4,doc.getDireccion());
            ps.setString(5,doc.getEspecializacion());
            ps.setDouble(6,doc.getPrecio());          
            ps.setInt(7,doc.getId());
            
            ps.execute();
   
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }

    public boolean eliminarDoctores(int _id){
    
        PreparedStatement ps;
        
        try{
            ps = Conexion.prepareStatement("DELETE FROM cit_med_doctores WHERE cit_med_doctoresid=?");
            ps.setInt(1,_id);
            ps.execute();
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
    }
}
