/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class conexion {
    
    public Connection getConexion(){
    try{
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/citasmedicas?useTimeZone=true&serverTimezone=UTC&autoReconnect=true&useSSL=false","root","1234");
        System.out.println("Conexion exitosa");
        return conexion;
        
    } catch(SQLException e){
        System.out.println(e.toString());
        return null;
    }
    
    }
}
