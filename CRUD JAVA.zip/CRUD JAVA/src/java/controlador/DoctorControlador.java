/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.doctor;
import modelo.doctorDAO;

@WebServlet(name = "DoctorControlador", urlPatterns = {"/DoctorControlador"})
public class DoctorControlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DoctorControlador</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DoctorControlador at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        doctorDAO doctorDAO = new doctorDAO();
        String accion;
        RequestDispatcher dispatcher=null;
        accion = request.getParameter("accion");
        
        if (accion== null || accion.isEmpty()) {
            dispatcher = request.getRequestDispatcher("doctores/index.jsp");
            List<doctor> listadoctor = doctorDAO.listarDoctores();
            request.setAttribute("lista",listadoctor);
        }
        else if ("nuevo".equals(accion)){
            dispatcher = request.getRequestDispatcher("doctores/nuevo.jsp");
        }
        else if ("insertar".equals(accion)){
            
            String nombre = request.getParameter("nombre");
            String telefono = request.getParameter("telefono");
            String correo = request.getParameter("correo");
            String direccion = request.getParameter("direccion");
            String especializacion = request.getParameter("especializacion");
            Double tarifa = Double.parseDouble(request.getParameter("tarifa"));
            Date fecha = null;
            
            doctor doc = new doctor(0,nombre, telefono, correo, direccion, especializacion, tarifa, fecha);
            doctorDAO.insertarDoctores(doc);
            dispatcher = request.getRequestDispatcher("doctores/index.jsp");
            List<doctor> listadoctor = doctorDAO.listarDoctores();
            request.setAttribute("lista",listadoctor);
        }
        
        else if ("modificar".equals(accion)){
            dispatcher = request.getRequestDispatcher("doctores/modificar.jsp");
            int id = Integer.parseInt(request.getParameter("id"));
            doctor doc = doctorDAO.mostrarDoctores(id);
            request.setAttribute("doctor",doc);
        
        }       
        else if ("actualizar".equals(accion)){
            
            int id = Integer.parseInt(request.getParameter("id"));
            String nombre = request.getParameter("nombre");
            String telefono = request.getParameter("telefono");
            String correo = request.getParameter("correo");
            String direccion = request.getParameter("direccion");
            String especializacion = request.getParameter("especializacion");
            Double tarifa = Double.parseDouble(request.getParameter("tarifa"));
            Date fecha = null;
            
            doctor doc = new doctor(id,nombre, telefono, correo, direccion, especializacion, tarifa, fecha);
            doctorDAO.actualizarDoctores(doc);
            dispatcher = request.getRequestDispatcher("doctores/index.jsp");
            List<doctor> listadoctor = doctorDAO.listarDoctores();
            request.setAttribute("lista",listadoctor);
        }
        
        else if ("eliminar".equals(accion)){
            int id = Integer.parseInt(request.getParameter("id"));
            doctorDAO.eliminarDoctores(id);
            dispatcher = request.getRequestDispatcher("doctores/index.jsp");
            List<doctor> listadoctor = doctorDAO.listarDoctores();
            request.setAttribute("lista",listadoctor);
        }
        
        else{
            dispatcher = request.getRequestDispatcher("doctores/index.jsp");
            List<doctor> listadoctor = doctorDAO.listarDoctores();
            request.setAttribute("lista",listadoctor);
        }
        dispatcher.forward(request,response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet (request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
