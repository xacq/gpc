# LIBRERIAS DE PYTHON IMPORTADAS
import random
import pandas as pd
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets


# FUNCION QUE PERMITE EVALUAR LA PRIMERA POBLACION ALEATORIA VERIFICADA POR LPSP<2%
def poblacion(individuo, data, parametros, control):
    hor = data.iloc[:, 0]  # aislamos la primera columna que posee las horas
    rad = data.iloc[:, 1]  # aislamos la segunda columna que posee la radicacion
    tem = data.iloc[:, 2]  # aislamos la tercera columna que posee la temperatura
    vel = data.iloc[:, 3]  # aislamos la tercera columna que posee la velocidad
    eca = data.iloc[:, 4]  # aislamos la tercera columna que posee la eca

    aero1 = individuo[0]
    aero2 = individuo[1]
    aero3 = individuo[2]
    aero4 = individuo[3]
    foto1 = individuo[4]
    foto2 = individuo[5]
    foto3 = individuo[6]
    bater = individuo[7]

    if bater == 0:
        individuo[7] = 1
        bater = 1

    for t in range(len(hor)):
        if aero1 > 0:  # CONDICION PARA CUANDO EL PRIMER ALELO EXISTE EN EL INDIVIDUO
            if vel[t] < parametros[6]:
                pwt1 = 0
            elif parametros[6] <= vel[t] < parametros[14]:
                pwt1 = ((parametros[2] / (parametros[14] ** 3 - parametros[6] ** 3)) * (vel[t] ** 3)) - (
                        (parametros[6] ** 3 / (parametros[14] ** 3 - parametros[6] ** 3)) * parametros[2])
            elif parametros[14] <= vel[t] < parametros[10]:
                pwt1 = parametros[2]
            elif vel[t] > parametros[10]:
                pwt1 = 0
        else:
            pwt1 = 0

        if aero2 > 0:
            if vel[t] < parametros[7]:
                pwt2 = 0
            elif parametros[7] <= vel[t] < parametros[15]:
                pwt2 = ((parametros[3] / (parametros[15] ** 3 - parametros[7] ** 3)) * (vel[t] ** 3)) - (
                        (parametros[7] ** 3 / (parametros[15] ** 3 - parametros[7] ** 3)) * parametros[3])
            elif parametros[15] <= vel[t] < parametros[11]:
                pwt2 = parametros[3]
            elif vel[t] > parametros[11]:
                pwt2 = 0
        else:
            pwt2 = 0

        if aero3 > 0:
            if vel[t] < parametros[8]:
                pwt3 = 0
            elif parametros[8] <= vel[t] < parametros[16]:
                pwt3 = ((parametros[4] / (parametros[16] ** 3 - parametros[8] ** 3)) * vel[t] ** 3) - (
                        (parametros[8] ** 3 / (parametros[16] ** 3 - parametros[8] ** 3)) * parametros[4])
            elif parametros[16] <= vel[t] < parametros[12]:
                pwt3 = parametros[4]
            elif vel[t] > parametros[10]:
                pwt3 = 0
        else:
            pwt3 = 0

        if aero4 > 0:
            if vel[t] < parametros[9]:
                pwt4 = 0
            elif parametros[9] <= vel[t] < parametros[17]:
                pwt4 = ((parametros[5] / (parametros[17] ** 3 - parametros[9] ** 3)) * vel[t] ** 3) - (
                        (parametros[9] ** 3 / (parametros[17] ** 3 - parametros[9] ** 3)) * parametros[5])
            elif parametros[17] <= vel[t] < parametros[13]:
                pwt4 = parametros[5]
            elif vel[t] > parametros[10]:
                pwt4 = 0
        else:
            pwt4 = 0

        Tct1 = tem[t] + (((parametros[35] - 20) / 800) * rad[t])
        Tct2 = tem[t] + (((parametros[36] - 20) / 800) * rad[t])
        Tct3 = tem[t] + (((parametros[37] - 20) / 800) * rad[t])

        if foto1 <= 0:
            ppvt1 = 0
        else:
            ppvt1 = parametros[26] * (rad[t] / parametros[0]) * (1 + (parametros[41] * (Tct1 - parametros[1])))
            if ppvt1 > parametros[26]:
                ppvt1 = parametros[26]
            if ppvt1 < 0:
                ppvt1 = 0

        if foto2 <= 0:
            Ppvt2 = 0
        else:
            Ppvt2 = parametros[27] * (rad[t] / parametros[0]) * (1 + (parametros[42] * (Tct2 - parametros[1])))
            if Ppvt2 > parametros[27]:
                Ppvt2 = parametros[27]
            if Ppvt2 < 0:
                Ppvt2 = 0

        if foto3 <= 0:
            Ppvt3 = 0
        else:
            Ppvt3 = (parametros[28] * (rad[t] / parametros[0])) * (1 + (parametros[43] * (Tct3 - parametros[1])))
            if Ppvt3 > parametros[28]:
                Ppvt3 = parametros[28]
            if Ppvt3 < 0:
                Ppvt3 = 0

        Ewtt = (aero1 * pwt1) + (aero2 * pwt2) + (aero3 * pwt3) + (aero4 * pwt4)
        Epvt = (foto1 * ppvt1) + (foto2 * Ppvt2) + (foto3 * Ppvt3)

        if bater > 0:
            if (Epvt + Ewtt) > eca[t]:
                if t == 0:  # Cuando empieza la primera vez en el calculo general
                    Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                    Ebt = (((1 - parametros[52]) * parametros[50]) * (1 - parametros[54])) + (
                            (((Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2))) - (
                                    eca[t] / parametros[56])) * parametros[51])
                else:
                    Ebt = (Ebt_anterior * (1 - parametros[54])) + (
                            (((Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2))) - (
                                    eca[t] / parametros[56])) * parametros[51])
                    Ebt_anterior = Ebt
            elif (Epvt + Ewtt) < eca[t]:
                if t == 0:  # Cuando empieza la primera vez en el calculo general
                    Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                    Ebt = (((1 - parametros[52]) * parametros[50]) * (1 - parametros[54])) - (
                            ((eca[t] / parametros[56]) - (
                                    (Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2)))) / parametros[
                                51] ** -1)
                else:
                    Ebt = Ebt_anterior * (1 - parametros[54]) - (
                            ((eca[t] / parametros[56]) - (
                                    (Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2)))) / parametros[
                                51] ** -1)
                    Ebt_anterior = Ebt

        if Ebt_anterior < ((1 - parametros[52]) * parametros[50]):
            Ebt_anterior = ((1 - parametros[52]) * parametros[50])
        elif Ebt < ((1 - parametros[52]) * parametros[50]):
            Ebt = ((1 - parametros[52]) * parametros[50])
        elif Ebt_anterior > 1350:
            Ebt_anterior = 1350
        elif Ebt > 1350:
            Ebt = 1350

        if t == 0:
            rb = abs(((1 - parametros[52]) * parametros[50]) - Ebt) / ((1 - parametros[52]) * parametros[50])
            if rb > 1:
                rb = 1
        else:
            rb = abs(Ebt_anterior - Ebt) / Ebt_anterior
            if rb > 1:
                rb = 1

        if (Epvt + Ewtt) > eca[t]:  # Caso de carga
            if rb > parametros[53]:
                if t == 0:
                    Ebt = ((1 - parametros[52]) * parametros[50]) + (
                            parametros[53] * ((1 - parametros[52]) * parametros[50]))
                else:
                    Ebt = Ebt_anterior + (parametros[53] * Ebt_anterior)
        elif (Epvt + Ewtt) < eca[t]:
            if rb > parametros[53]:
                if t == 0:
                    Ebt = ((1 - parametros[52]) * parametros[50]) - (
                            parametros[53] * ((1 - parametros[52]) * parametros[50]))
                else:
                    Ebt = Ebt_anterior - (parametros[53] * Ebt_anterior)

        if Ebt_anterior < ((1 - parametros[52]) * parametros[50]):
            Ebt_anterior = ((1 - parametros[52]) * parametros[50])
        elif Ebt < ((1 - parametros[52]) * parametros[50]):
            Ebt = ((1 - parametros[52]) * parametros[50])
        elif Ebt_anterior > 1350:
            Ebt_anterior = 1350
        elif Ebt > 1350:
            Ebt = 1350

        Ebt_extra = Ebt - Ebt_anterior

        if Ebt_extra < 0:
            Abt = abs(Ebt_extra)
            Alt = 0
        elif Ebt_extra > 0:
            Alt = abs(Ebt_extra)
            Abt = 0
        else:
            Alt = 0
            Abt = 0

        Egen = ((aero1 * pwt1) + (aero2 * pwt2) + (aero3 * pwt3) + (aero4 * pwt4)) + (
                (foto1 * ppvt1) + (foto2 * Ppvt2) + (foto3 * Ppvt3))

        if (Egen - eca[t]) > 0:
            Eren = Egen - Alt
        elif (Egen - eca[t]) < 0:
            Eren = Egen + Abt
        elif (Egen - eca[t]) == 0:
            Eren = eca

        if t == 0:
            Lpsp_sumado = (eca[t] - Eren)
        else:
            Lpsp_sumado = Lpsp_sumado + (eca[t] - Eren)

    ecasumado = sum(eca)
    LPSP = Lpsp_sumado / ecasumado

    if control == 0:
        if -1 < LPSP < 0.02:
            return individuo
        else:
            return 1
    elif control == 1:
        return Eren

class Ui_MainWindow(object):

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1000, 600)
        MainWindow.setMinimumSize(QtCore.QSize(1000, 600))
        MainWindow.setMaximumSize(QtCore.QSize(1000, 600))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.label_00 = QtWidgets.QLabel(self.centralwidget)
        self.label_00.setGeometry(QtCore.QRect(0, 0, 300, 80))
        self.label_00.setMinimumSize(QtCore.QSize(300, 80))
        self.label_00.setMaximumSize(QtCore.QSize(300, 80))
        self.label_00.setText("")
        self.label_00.setPixmap(QtGui.QPixmap("logoupscolor(2).svg"))
        self.label_00.setAlignment(QtCore.Qt.AlignCenter)
        self.label_00.setWordWrap(True)
        self.label_00.setObjectName("label_00")

        self.label_01 = QtWidgets.QLabel(self.centralwidget)
        self.label_01.setGeometry(QtCore.QRect(300, 10, 681, 61))
        font = QtGui.QFont()
        font.setPointSize(26)
        font.setBold(False)
        font.setWeight(50)
        self.label_01.setFont(font)
        self.label_01.setAlignment(QtCore.Qt.AlignCenter)
        self.label_01.setObjectName("label_01")

        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(10, 90, 271, 461))
        self.groupBox.setObjectName("groupBox")

        self.pushButton_0 = QtWidgets.QPushButton(self.groupBox)
        self.pushButton_0.setGeometry(QtCore.QRect(10, 20, 241, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushButton_0.setFont(font)
        self.pushButton_0.setObjectName("pushButton_0")
        self.pushButton_0.clicked.connect(self.clickparametros)

        self.listWidget = QtWidgets.QListWidget(self.groupBox)
        self.listWidget.setGeometry(QtCore.QRect(10, 110, 251, 91))
        self.listWidget.setObjectName("listWidget")

        self.listWidget_2 = QtWidgets.QListWidget(self.groupBox)
        self.listWidget_2.setGeometry(QtCore.QRect(10, 235, 251, 91))
        self.listWidget_2.setObjectName("listWidget_2")

        self.listWidget_3 = QtWidgets.QListWidget(self.groupBox)
        self.listWidget_3.setGeometry(QtCore.QRect(10, 360, 251, 91))
        self.listWidget_3.setObjectName("listWidget_3")

        self.label_1 = QtWidgets.QLabel(self.groupBox)
        self.label_1.setGeometry(QtCore.QRect(10, 80, 251, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_1.setFont(font)
        self.label_1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_1.setObjectName("label_1")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 210, 251, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(10, 331, 251, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_3.setFont(font)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")

        self.groupBox_2 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(290, 90, 211, 461))
        self.groupBox_2.setObjectName("groupBox_2")

        self.pushButton_1 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_1.setGeometry(QtCore.QRect(10, 27, 191, 20))
        self.pushButton_1.setObjectName("pushButton_1")
        self.pushButton_1.clicked.connect(self.banos)

        self.pushButton_2 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_2.setGeometry(QtCore.QRect(10, 51, 191, 20))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.cajas)

        self.pushButton_3 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_3.setGeometry(QtCore.QRect(10, 75, 191, 20))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.chaucha)

        self.pushButton_4 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_4.setGeometry(QtCore.QRect(10, 99, 191, 20))
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_4.clicked.connect(self.cts)

        self.pushButton_8 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_8.setGeometry(QtCore.QRect(10, 195, 191, 20))
        self.pushButton_8.setObjectName("pushButton_8")
        self.pushButton_8.clicked.connect(self.molleturo)

        self.pushButton_7 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_7.setGeometry(QtCore.QRect(10, 171, 191, 20))
        self.pushButton_7.setObjectName("pushButton_7")
        self.pushButton_7.clicked.connect(self.llacao)

        self.pushButton_6 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_6.setGeometry(QtCore.QRect(10, 147, 191, 21))
        self.pushButton_6.setObjectName("pushButton_6")
        self.pushButton_6.clicked.connect(self.irquis)

        self.pushButton_5 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_5.setGeometry(QtCore.QRect(10, 123, 191, 20))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.clicked.connect(self.cumbe)

        self.pushButton_11 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_11.setGeometry(QtCore.QRect(10, 267, 191, 20))
        self.pushButton_11.setObjectName("pushButton_11")
        self.pushButton_11.clicked.connect(self.sanjoaquin)

        self.pushButton_13 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_13.setGeometry(QtCore.QRect(10, 315, 191, 20))
        self.pushButton_13.setObjectName("pushButton_13")
        self.pushButton_13.clicked.connect(self.sayausi)

        self.pushButton_15 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_15.setGeometry(QtCore.QRect(10, 363, 191, 20))
        self.pushButton_15.setObjectName("pushButton_15")
        self.pushButton_15.clicked.connect(self.tixan)

        self.pushButton_10 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_10.setGeometry(QtCore.QRect(10, 243, 191, 20))
        self.pushButton_10.setObjectName("pushButton_10")
        self.pushButton_10.clicked.connect(self.quingeo)

        self.pushButton_12 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_12.setGeometry(QtCore.QRect(10, 291, 191, 20))
        self.pushButton_12.setObjectName("pushButton_12")
        self.pushButton_12.clicked.connect(self.santana)

        self.pushButton_14 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_14.setGeometry(QtCore.QRect(10, 339, 191, 20))
        self.pushButton_14.setObjectName("pushButton_14")
        self.pushButton_14.clicked.connect(self.sinincay)

        self.pushButton_9 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_9.setGeometry(QtCore.QRect(10, 219, 191, 20))
        self.pushButton_9.setObjectName("pushButton_9")
        self.pushButton_9.clicked.connect(self.nulti)

        self.pushButton_16 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_16.setGeometry(QtCore.QRect(10, 387, 191, 20))
        self.pushButton_16.setObjectName("pushButton_16")
        self.pushButton_16.clicked.connect(self.turi)

        self.pushButton_17 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_17.setGeometry(QtCore.QRect(10, 410, 191, 20))
        self.pushButton_17.setObjectName("pushButton_17")
        self.pushButton_17.clicked.connect(self.ups)

        self.pushButton_18 = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_18.setGeometry(QtCore.QRect(10, 433, 191, 20))
        self.pushButton_18.setObjectName("pushButton_17")
        self.pushButton_18.clicked.connect(self.close)

        self.groupBox_3 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_3.setGeometry(QtCore.QRect(510, 89, 481, 461))
        self.groupBox_3.setObjectName("groupBox_3")

        self.label_4 = QtWidgets.QLabel(self.groupBox_3)
        self.label_4.setGeometry(QtCore.QRect(10, 20, 461, 16))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_4.setFont(font)
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")

        self.listWidget_4 = QtWidgets.QListWidget(self.groupBox_3)
        self.listWidget_4.setGeometry(QtCore.QRect(10, 40, 460, 400))
        self.listWidget_4.setObjectName("listWidget")

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1000, 21))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionArchivos_Excel = QtWidgets.QAction(MainWindow)
        self.actionArchivos_Excel.setObjectName("actionArchivos_Excel")
        self.actionArchivos_Sensores = QtWidgets.QAction(MainWindow)
        self.actionArchivos_Sensores.setObjectName("actionArchivos_Sensores")
        self.actionSalir = QtWidgets.QAction(MainWindow)
        self.actionSalir.setObjectName("actionSalir")
        self.actionAcerca_de = QtWidgets.QAction(MainWindow)
        self.actionAcerca_de.setObjectName("actionAcerca_de")
        self.actionSalir_2 = QtWidgets.QAction(MainWindow)
        self.actionSalir_2.setObjectName("actionSalir_2")
        self.menu.addAction(self.actionSalir_2)
        self.menubar.addAction(self.menu.menuAction())
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "OPTIMIZACION A TRAVES DE ALGORITMO GENETICO"))
        self.label_01.setText(_translate("MainWindow", "Optimizacion a traves de algoritmo AG"))
        self.groupBox.setTitle(_translate("MainWindow", "Datos Técnicos"))
        self.pushButton_0.setText(_translate("MainWindow", "Cargar archivo con Parametros"))
        self.label_1.setText(_translate("MainWindow", "AEROGENERADORES"))
        self.label_2.setText(_translate("MainWindow", "PLACAS FOTOVOLTAICAS"))
        self.label_3.setText(_translate("MainWindow", "BATERIAS"))

        self.groupBox_2.setTitle(_translate("MainWindow", "Datos a connsiderar en la GA"))
        self.pushButton_1.setText(_translate("MainWindow", "Baños - Soldados"))
        self.pushButton_2.setText(_translate("MainWindow", "Cajas"))
        self.pushButton_3.setText(_translate("MainWindow", "Chaucha"))
        self.pushButton_4.setText(_translate("MainWindow", "CTS"))
        self.pushButton_8.setText(_translate("MainWindow", "Molleturo"))
        self.pushButton_7.setText(_translate("MainWindow", "Llacao"))
        self.pushButton_6.setText(_translate("MainWindow", "Irquis"))
        self.pushButton_5.setText(_translate("MainWindow", "Cumbe"))
        self.pushButton_11.setText(_translate("MainWindow", "San Joaquin"))
        self.pushButton_13.setText(_translate("MainWindow", "Sayausí"))
        self.pushButton_15.setText(_translate("MainWindow", "Tixán"))
        self.pushButton_10.setText(_translate("MainWindow", "Quingeo"))
        self.pushButton_12.setText(_translate("MainWindow", "Santa Ana"))
        self.pushButton_14.setText(_translate("MainWindow", "Sinincay"))
        self.pushButton_9.setText(_translate("MainWindow", "Nulti"))
        self.pushButton_16.setText(_translate("MainWindow", "Turi"))
        self.pushButton_17.setText(_translate("MainWindow", "UPS"))
        self.pushButton_18.setText(_translate("MainWindow", "S A L I R"))

        self.groupBox_3.setTitle(_translate("MainWindow", "Resultados"))
        self.label_4.setText(_translate("MainWindow", "INDIVIDUOS POR GENERACION Y RESULTADOS"))

    def close(self):
        self.close()

    def clickparametros(self):
        aeros = pd.read_excel("Data.xls", 17)
        volts = pd.read_excel("Data.xls", 18)
        bates = pd.read_excel("Data.xls", 19)
        aero = aeros.iloc[:, 2]
        volt = volts.iloc[:, 2]
        bate = bates.iloc[:, 2]
        self.listWidget.addItems(aero)
        self.listWidget_2.addItems(volt)
        self.listWidget_3.addItems(bate)

    # GENERA LA POBLACION INICIAL
    def crear_poblacion_inicial(self, minimo, maximo, data, total_individuos, parametros):
        # METODO DE LA CLASE QUE RECIBE COMO VALORES DE MAXIMO Y MINIMO COMO RANGO DE VALORES PARA CADA ALELO O GEN
        # TAMBIEN RECIBE EL DATA DEL ARCHIVO SELECCIONADO, EL MISMO GENERARA A TRAVES DE UN LOOP TIPO WHILE UNA LISTA
        # CON 64 INDIVIDUOS QUE YA ESTAN VERIFICAOOS Y CON LOS QUE EMPEZAREMOS EL ALGORITMO
        aleatorios = [] * total_individuos  # SE GENERA UNA LISTA VACIA CON EL TOTAL DE INDIVIDUOS INICIALES
        i = 0  # INICIAMOS EL CONTADOR POR QUE NECESITA UN VALOR INICIAL PARA PODER MANIPULARSE DENTRO DEL LOOP WHILE
        while i < total_individuos:  # CONDICION QUE CONTROLARA EL NUMERO DE INDIVIDUOS EN LA LISTA ALEATORIOS
            individuo = [random.randint(minimo, maximo) for _ in range(8)]
            individuo_valido = poblacion(individuo, data, parametros, 0)
            if individuo_valido != 1:  # VERIFICA EL VALOR QUE DEVUELVE LA FUNCION SI ES DISTINTO QUE 1 INGRESA AL IF
                aleatorios.append(individuo_valido)  # AÑADE EL INDIVIDUO A LA LISTA
                i = i + 1  # AUMENTA EN UNO EL CONTADOR QUE CONTROLA EL TOTAL DE INDIVIDUOS
        return aleatorios  # RETURNA LA LISTA CON INDIVIDUOS VALIDOS

        # APLICA LA FUNCION PARA VERIFICAR EL LPSP SOBRE EL OBJETIVO TOMANDO EN CUENTA LOS DATOS DEL ARCHIVO
    def fitness(self, poblacion, data, generacion, parametros, individuos):
        vector = [] * int(individuos)
        print("***************** DATOS DE LA GENERACION [", generacion , "] *****************")
        hor = data.iloc[:, 0]  # aislamos la primera columna que posee las horas
        rad = data.iloc[:, 1]  # aislamos la segunda columna que posee la radicacion
        tem = data.iloc[:, 2]  # aislamos la tercera columna que posee la temperatura
        vel = data.iloc[:, 3]  # aislamos la tercera columna que posee la velocidad
        eca = data.iloc[:, 4]  # aislamos la tercera columna que posee la eca
        i = 0
        while i < individuos:  # ASIGNAMOS LOS VALORES DE CADA GEN DEL INDIVIDUO A VARIABLES
            Lpsp_sumado = 0
            aero1 = poblacion[i][0]
            aero2 = poblacion[i][1]
            aero3 = poblacion[i][2]
            aero4 = poblacion[i][3]
            foto1 = poblacion[i][4]
            foto2 = poblacion[i][5]
            foto3 = poblacion[i][6]
            bater = poblacion[i][7]
            if bater == 0:
                poblacion[i][7] = 1
                bater = 1

            for t in range(len(hor)):
                if aero1 > 0:  # CONDICION PARA CUANDO EL PRIMER ALELO EXISTE EN EL INDIVIDUO
                    if vel[t] < parametros[6]:
                        pwt1 = 0
                    elif parametros[6] <= vel[t] < parametros[14]:
                        pwt1 = ((parametros[2] / (parametros[14] ** 3 - parametros[6] ** 3)) * (vel[t] ** 3)) - (
                                (parametros[6] ** 3 / (parametros[14] ** 3 - parametros[6] ** 3)) * parametros[2])
                    elif parametros[14] <= vel[t] < parametros[10]:
                        pwt1 = parametros[2]
                    elif vel[t] > parametros[10]:
                        pwt1 = 0
                else:
                    pwt1 = 0

                if aero2 > 0:
                    if vel[t] < parametros[7]:
                        pwt2 = 0
                    elif parametros[7] <= vel[t] < parametros[15]:
                        pwt2 = ((parametros[3] / (parametros[15] ** 3 - parametros[7] ** 3)) * (vel[t] ** 3)) - (
                                (parametros[7] ** 3 / (parametros[15] ** 3 - parametros[7] ** 3)) * parametros[3])
                    elif parametros[15] <= vel[t] < parametros[11]:
                        pwt2 = parametros[3]
                    elif vel[t] > parametros[11]:
                        pwt2 = 0
                else:
                    pwt2 = 0

                if aero3 > 0:
                    if vel[t] < parametros[8]:
                        pwt3 = 0
                    elif parametros[8] <= vel[t] < parametros[16]:
                        pwt3 = ((parametros[4] / (parametros[16] ** 3 - parametros[8] ** 3)) * vel[t] ** 3) - (
                                (parametros[8] ** 3 / (parametros[16] ** 3 - parametros[8] ** 3)) * parametros[4])
                    elif parametros[16] <= vel[t] < parametros[12]:
                        pwt3 = parametros[4]
                    elif vel[t] > parametros[10]:
                        pwt3 = 0
                else:
                    pwt3 = 0

                if aero4 > 0:
                    if vel[t] < parametros[9]:
                        pwt4 = 0
                    elif parametros[9] <= vel[t] < parametros[17]:
                        pwt4 = ((parametros[5] / (parametros[17] ** 3 - parametros[9] ** 3)) * vel[t] ** 3) - (
                                (parametros[9] ** 3 / (parametros[17] ** 3 - parametros[9] ** 3)) * parametros[5])
                    elif parametros[17] <= vel[t] < parametros[13]:
                        pwt4 = parametros[5]
                    elif vel[t] > parametros[10]:
                        pwt4 = 0
                else:
                    pwt4 = 0

                Tct1 = tem[t] + (((parametros[35] - 20) / 800) * rad[t])
                Tct2 = tem[t] + (((parametros[36] - 20) / 800) * rad[t])
                Tct3 = tem[t] + (((parametros[37] - 20) / 800) * rad[t])

                if foto1 <= 0:
                    ppvt1 = 0
                else:
                    ppvt1 = parametros[26] * (rad[t] / parametros[0]) * (1 + (parametros[41] * (Tct1 - parametros[1])))
                    if ppvt1 > parametros[26]:                ppvt1 = parametros[26]
                    if ppvt1 < 0:                ppvt1 = 0

                if foto2 <= 0:
                    Ppvt2 = 0
                else:
                    Ppvt2 = parametros[27] * (rad[t] / parametros[0]) * (1 + (parametros[42] * (Tct2 - parametros[1])))
                    if Ppvt2 > parametros[27]:                Ppvt2 = parametros[27]
                    if Ppvt2 < 0:                Ppvt2 = 0

                if foto3 <= 0:
                    Ppvt3 = 0
                else:
                    Ppvt3 = (parametros[28] * (rad[t] / parametros[0])) * (
                                1 + (parametros[43] * (Tct3 - parametros[1])))
                    if Ppvt3 > parametros[28]:                Ppvt3 = parametros[28]
                    if Ppvt3 < 0:                Ppvt3 = 0

                Ewtt = (aero1 * pwt1) + (aero2 * pwt2) + (aero3 * pwt3) + (aero4 * pwt4)
                Epvt = (foto1 * ppvt1) + (foto2 * Ppvt2) + (foto3 * Ppvt3)
                if bater > 0:
                    if (Epvt + Ewtt) > eca[t]:
                        if t == 0:  # Cuando empieza la primera vez en el calculo general
                            Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                            Ebt = (((1 - parametros[52]) * parametros[50]) * (1 - parametros[54])) + (
                                    (((Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2))) - (
                                                eca[t] / parametros[56])) * parametros[51])
                        else:
                            Ebt = (Ebt_anterior * (1 - parametros[54])) + (
                                    (((Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2))) - (
                                                eca[t] / parametros[56])) * parametros[51])
                            Ebt_anterior = Ebt
                    elif (Epvt + Ewtt) < eca[t]:
                        if t == 0:  # Cuando empieza la primera vez en el calculo general
                            Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                            Ebt = (((1 - parametros[52]) * parametros[50]) * (1 - parametros[54])) - (
                                    ((eca[t] / parametros[56]) - (
                                                (Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2)))) / parametros[
                                        51] ** -1)
                        else:
                            Ebt = Ebt_anterior * (1 - parametros[54]) - (
                                    ((eca[t] / parametros[56]) - (
                                                (Epvt * parametros[56]) + (Ewtt * (parametros[56] ** 2)))) / parametros[
                                        51] ** -1)
                            Ebt_anterior = Ebt

                if Ebt_anterior < ((1 - parametros[52]) * parametros[50]):
                    Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                elif Ebt < ((1 - parametros[52]) * parametros[50]):
                    Ebt = ((1 - parametros[52]) * parametros[50])
                elif Ebt_anterior > 1350:
                    Ebt_anterior = 1350
                elif Ebt > 1350:
                    Ebt = 1350

                if t == 0:
                    rb = abs(((1 - parametros[52]) * parametros[50]) - Ebt) / ((1 - parametros[52]) * parametros[50])
                    if rb > 1:
                        rb = 1
                else:
                    rb = abs(Ebt_anterior - Ebt) / Ebt_anterior
                    if rb > 1:
                        rb = 1

                if (Epvt + Ewtt) > eca[t]:  # Caso de carga
                    if rb > parametros[53]:
                        if t == 0:
                            Ebt = ((1 - parametros[52]) * parametros[50]) + (
                                        parametros[53] * ((1 - parametros[52]) * parametros[50]))
                        else:
                            Ebt = Ebt_anterior + (parametros[53] * Ebt_anterior)
                elif (Epvt + Ewtt) < eca[t]:
                    if rb > parametros[53]:
                        if t == 0:
                            Ebt = ((1 - parametros[52]) * parametros[50]) - (
                                        parametros[53] * ((1 - parametros[52]) * parametros[50]))
                        else:
                            Ebt = Ebt_anterior - (parametros[53] * Ebt_anterior)

                if Ebt_anterior < ((1 - parametros[52]) * parametros[50]):
                    Ebt_anterior = ((1 - parametros[52]) * parametros[50])
                elif Ebt < ((1 - parametros[52]) * parametros[50]):
                    Ebt = ((1 - parametros[52]) * parametros[50])
                elif Ebt_anterior > 1350:
                    Ebt_anterior = 1350
                elif Ebt > 1350:
                    Ebt = 1350

                Ebt_extra = Ebt - Ebt_anterior
                if Ebt_extra < 0:
                    Abt = abs(Ebt_extra)
                    Alt = 0
                elif Ebt_extra > 0:
                    Alt = abs(Ebt_extra)
                    Abt = 0
                else:
                    Alt = 0
                    Abt = 0

                Egen = ((aero1 * pwt1) + (aero2 * pwt2) + (aero3 * pwt3) + (aero4 * pwt4)) + (
                        (foto1 * ppvt1) + (foto2 * Ppvt2) + (foto3 * Ppvt3))
                if (Egen - eca[t]) > 0:
                    Eren = Egen - Alt
                elif (Egen - eca[t]) < 0:
                    Eren = Egen + Abt
                elif (Egen - eca[t]) == 0:
                    Eren = eca

                if t == 0:
                    Lpsp_sumado = (eca[t] - Eren)
                else:
                    Lpsp_sumado = Lpsp_sumado + (eca[t] - Eren)

            ecasumado = sum(eca)
            LPSP = Lpsp_sumado / ecasumado
            #SECCION DEL CODIGO DONDE SE REALIZA EL PASO DE SELECCION DE LOS INDIVIDUOS DENTRO DEL
            #TEOREMA DE ALGORITMO GENETICO
            if -1 < LPSP < 0.02:
                vector.append(LPSP)
                print("INDIVIDUO SELECCIONADO:[", i, "]", poblacion[i], " => LPSP: ", LPSP)
            i = i + 1
        return vector

        # METODO QUE LOGRA REPRODUCIR DE LOS ESCOGIDOS LOS INDIVIDUOS QUE FORMARAN LA NUEVA POBLACION
    def reproduccion(self, padres, total_individuos):
        #  EL METODO RECIBE COMO PARAMETROS LA LISTA DE INDIVIDUOS SELECCIONADOS DE LA POBLACION Y EL NUMERO INDIVIDUOS
        #  PARA LA SIGUIENTE GENERACION. EL METODO CREA UN ARRAY CON EL TOTAL DE INDIVIDUOS Y A TRAVES DE UN LOOP FOR
        #  SELECCIONA ALEATORIAMENTE 2 PADRES DE LA LISTA Y LOS CRUZA NACIENDO DE ESTE CRUCE UN HIJO.  EL NUMERO DEL
        #  CRUCE ES LA MITAD DEL NUMERO DE GENES O ALELOS
        hijos = [] * total_individuos
        for i in range(total_individuos):
            father = random.sample(padres, 2)  # SELECCIONA ALEATORIAMENTE 2 PADRES
            hijos.append(father[0][:4] + father[1][4:])
        return hijos

        # METODO QUE MUTA UN VALOR DE CADA INDIVIDUO
    def mutacion(self, hijos, rango, maximo):
        #  EL METODO RECIBE COMO PARAMETRO LA LISTA DE HIJOS RESULTANTES DE LA REPRODUCCION DE LOS PADRES
        #  A TRAVES DE RECORRER CADA HIJO, SE ESCOJE UN VALOR RANDOMICO ENTRE 0 Y 7 PARA LA POSICION DEL
        #  GEN QUE SE VA A CAMBIAR, LUEGO SE GENERA UN VALOR ENTRE 0 Y 10 POR EL CUAL VAMOS A CAMBIAR DICHA POSICION
        #  Y ANTES DE CAMBIAR TAL DATO, VERIFICAMOS QUE EL VALOR GENERADO NO SEA IGUAL AL QUE YA EXISTE EN DICHA UBICACION
        for i in range(len(hijos)):
            if random.random() <= rango:  # CONDICION QUE VERIFICA QUE EL PARAMETRO PARA LA MUTACION SEA EL SELECCIONADO POR EL USUARIO
                posicion_mutar = random.randint(0,6)  # GENERAMOS UN VALOR ALEATORIO PARA LA POSICION EN EL INDIVIDUO A CAMBIAR
                valor_cambiar = random.randint(0,maximo)  # SELECCIONAMOS UN VALOR ALEATORI POR EL CUAL SE CAMBIARA EN EL GEN ESCOGIDO
                while valor_cambiar == hijos[i][
                    posicion_mutar]:  # LOOP WHILE QUE CONDICIONA QUE EL VALOR CREADO NO SEA IGUAL AL EXISTENTE
                    valor_cambiar = random.randint(0, maximo)
                hijos[i][posicion_mutar] = valor_cambiar
        return hijos

    # noinspection PyGlobalUndefined
    global individuos, maximo, generaciones, individuoresultante, lpspresultante, ir, a
    individuos = 64
    maximo = 2
    generaciones = 50
    ir = 0.2
    a = 20


    def calculogeneral (self, nombre, maximo,data, individuos, generaciones):
        archivo = open(nombre, "w")
        archivo.close()
        with open(nombre, "a") as f:
            f.write("*************CONTENIDO ARCHIVO [")
            f.write(str(nombre) + "] *************\n")
        datos = pd.read_excel("Data.xls",20)
        parametros = datos.iloc[:, 0]
        poblacion = self.crear_poblacion_inicial(0, maximo, data, individuos, parametros)
        for i in range(generaciones):
            vector_lpsp = self.fitness(poblacion, data, i, parametros, individuos)
            if i < generaciones - 1:
                desendencia = self.reproduccion(poblacion, individuos)
                with open(nombre, "a") as f:
                    f.write("*************INICIO DE GENERACION [")
                    gen = i
                    f.write(str(gen) + "] *************\n")
                    for item in poblacion:
                        f.write("%s\n" % item)
                    f.write("FIN DE GENERACION\n")
                mutados = self.mutacion(desendencia, 0.5, maximo)
                poblacion = mutados
        with open(nombre, "a") as f:
            f.write("*************INICIO DE GENERACION [")
            gen = i
            f.write(str(gen) + "] *************\n")
            for item in poblacion:
                f.write("%s\n" % item)
            f.write("*************FIN DE GENERACION*************\n")
        contador = 0
        i = 0
        individuoresultante = []
        lpspresultante = vector_lpsp
        lpspresultante = list(set(lpspresultante))
        lpspresultante.sort()
        while True:
            if contador < 4:
                if lpspresultante[contador] == vector_lpsp[i]:
                    individuoresultante.append(poblacion[i])
                    contador = contador + 1
                    i = 0
                else:
                    i = i + 1
            else:
                break
        with open(nombre, "a") as f:
            f.write("\nMEJORES INDIVIDUOS: \n")
            for item in individuoresultante:
                f.write("%s\n" % item)
            f.write("\n")
        porcion = lpspresultante[:4]
        with open(nombre, "a") as f:
            f.write("MEJORES LPSP: \n")
            for item in porcion:
                f.write("%s\n" % item)
        return individuoresultante

    def calculofinal(self, individuos, nombre, data):
        datos = pd.read_excel("Data.xls",20)
        parametros = datos.iloc[:, 0]
        CRF = (ir * (1 + ir)**a) / ((1+ir)**a - 1)
        CCCON = parametros[58] * (1+(1/((1+ir)**10)))
        CCB = parametros[57] * (1+(1/((1+ir)**5))+(1/((1+ir)**10))+(1/((1+ir)**15)))
        aera = 0
        aerb = 0
        aerc = 0
        aerd = 0
        fota = 0
        fotb = 0
        fotc = 0
        fotd = 0
        for i in range(4):
            if i == 0: dato = parametros[22]
            elif i == 1: dato = parametros[23]
            elif i == 2: dato = parametros[24]
            else: dato = parametros[24]
            aera = aera + (individuos[0][i] * dato)
            aerb = aerb + (individuos[1][i] * dato)
            aerc = aerc + (individuos[2][i] * dato)
            aerd = aerd + (individuos[3][i] * dato)
        for i in range(3,7):
            if i == 4: dato = parametros[47]
            elif i == 5: dato = parametros[48]
            elif i == 6: dato = parametros[49]
            fota = fota + (individuos[0][i] * dato)
            fotb = fotb + (individuos[1][i] * dato)
            fotc = fotc + (individuos[2][i] * dato)
            fotd = fotd + (individuos[2][i] * dato)
        CMTTOA = aera + fota
        CMTTOB = aerb + fotb
        CMTTOC = aerc + fotc
        CMTTOD = aerd + fotd

        aera = 0
        aerb = 0
        aerc = 0
        aerd = 0
        fota = 0
        fotb = 0
        fotc = 0
        fotd = 0
        for i in range(4):
            if i == 0: dato = parametros[18]
            elif i == 1: dato = parametros[19]
            elif i == 2: dato = parametros[20]
            else: dato = parametros[21]
            aera = aera + (individuos[0][i] * dato)
            aerb = aerb + (individuos[1][i] * dato)
            aerc = aerc + (individuos[2][i] * dato)
            aerd = aerd + (individuos[3][i] * dato)
        for i in range(3,7):
            if i == 4: dato = parametros[44]
            elif i == 5: dato = parametros[45]
            elif i == 6: dato = parametros[46]
            fota = fota + (individuos[0][i] * dato)
            fotb = fotb + (individuos[1][i] * dato)
            fotc = fotc + (individuos[2][i] * dato)
            fotd = fotd + (individuos[2][i] * dato)
        CCTTOA = aera + fota
        CCTTOB = aerb + fotb
        CCTTOC = aerc + fotc
        CCTTOD = aerd + fotd

        CCAPIA = CRF + (CCTTOA + (individuos[0][7] * CCB) + (1 * CCCON))
        CCAPIB = CRF + (CCTTOA + (individuos[1][7] * CCB) + (1 * CCCON))
        CCAPIC = CRF + (CCTTOA + (individuos[2][7] * CCB) + (1 * CCCON))
        CCAPID = CRF + (CCTTOA + (individuos[3][7] * CCB) + (1 * CCCON))

        TACA = CCAPIA + CMTTOA
        TACB = CCAPIB + CMTTOB
        TACC = CCAPIC + CMTTOC
        TACD = CCAPID + CMTTOD

        with open(nombre, "a") as f:
            f.write("\n********** DATOS TAC **********")
            f.write("\nTAC 1: ")
            f.write(str(TACA))
            f.write("\nTAC 2: ")
            f.write(str(TACB))
            f.write("\nTAC 3: ")
            f.write(str(TACC))
            f.write("\nTAC 4: ")
            f.write(str(TACD))

        ErenA = poblacion(individuos[0], data, parametros, 1)
        ErenB = poblacion(individuos[1], data, parametros, 1)
        ErenC = poblacion(individuos[2], data, parametros, 1)
        ErenD = poblacion(individuos[3], data, parametros, 1)

        LCOEA = TACA / ErenA
        LCOEB = TACB / ErenB
        LCOEC = TACC / ErenC
        LCOED = TACD / ErenD

        with open(nombre, "a") as f:
            f.write("\n********** DATOS LCOE **********")
            f.write("\nLCOE 1: ")
            f.write(str(LCOEA))
            f.write("\nLCOE 2: ")
            f.write(str(LCOEB))
            f.write("\nLCOE 3: ")
            f.write(str(LCOEC))
            f.write("\nLCOE 4: ")
            f.write(str(LCOED))
            f.write("\n************** FIN DE ARCHIVO**************")

        dat = []
        with open(nombre) as f:
            lineas = f.readlines()
            for linea in lineas:
                dat.append(linea.strip('\n'))
        self.listWidget_4.addItems(dat)

    def banos(self):
        nombre = "baños.txt"
        data = pd.read_excel("Data.xls", 0)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones,)
        self.calculofinal(individuo,nombre,data)

    def cajas(self):
        nombre = "cajas.txt"
        data = pd.read_excel("Data.xls", 1)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def chaucha(self):
        nombre = "chaucha.txt"
        data = pd.read_excel("Data.xls", 2)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def cts(self):
        nombre = "cts.txt"
        data = pd.read_excel("Data.xls", 3)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def cumbe(self):
        nombre = "cumbe.txt"
        data = pd.read_excel("Data.xls", 4)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def irquis(self):
        nombre = "irquis.txt"
        data = pd.read_excel("Data.xls", 5)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def llacao(self):
        nombre = "llacao.txt"
        data = pd.read_excel("Data.xls", 6)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def molleturo(self):
        nombre = "molleturo.txt"
        data = pd.read_excel("Data.xls", 7)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def nulti(self):
        nombre = "nulti.txt"
        data = pd.read_excel("Data.xls", 8)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def quingeo(self):
        nombre = "quingeo.txt"
        data = pd.read_excel("Data.xls", 9)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def sanjoaquin(self):
        nombre = "sanjoaquin.txt"
        data = pd.read_excel("Data.xls", 10)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def santana(self):
        nombre = "santana.txt"
        data = pd.read_excel("Data.xls", 11)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def sayausi(self):
        nombre = "sanjoaquin.txt"
        data = pd.read_excel("Data.xls", 12)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def sinincay(self):
        nombre = "sinincay.txt"
        data = pd.read_excel("Data.xls", 13)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def tixan(self):
        nombre = "tixan.txt"
        data = pd.read_excel("Data.xls", 14)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def turi(self):
        nombre = "turi.txt"
        data = pd.read_excel("Data.xls", 15)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)

    def ups(self):
        nombre = "ups.txt"
        data = pd.read_excel("Data.xls", 16)
        individuo = self.calculogeneral(nombre, maximo, data, individuos, generaciones)
        self.calculofinal(individuo,nombre,data)


if __name__ == "__main__":
    app = QApplication([])
    window = QMainWindow()
    main_window = Ui_MainWindow()
    main_window.setupUi(window)
    window.show()
    app.exec_()
